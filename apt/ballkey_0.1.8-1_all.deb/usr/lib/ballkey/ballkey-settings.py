#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""BallKey settings app: pick a device, choose an action for each button,
click Apply.

Runs as the normal user and never touches /dev/input itself; everything
goes through the BallKey daemon over the system D-Bus. Saving shows the
system password prompt (polkit).

Button combinations: pressing several buttons together can do their own
action, e.g. Left + Right together = Middle click (for a mouse without a
wheel).

Safety: if the new settings leave no button doing a left click, a
countdown asks "Keep these settings?" and reverts after 15 seconds
unless confirmed (like changing display resolution).
"""

import json
import os
import sys

from evdev import ecodes  # name tables only; no device access
from PySide6.QtCore import QObject, Qt, QTimer, Signal, Slot, SLOT
from PySide6.QtDBus import (QDBusConnection, QDBusInterface, QDBusMessage,
                            QDBusPendingCallWatcher)
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox,
                               QComboBox,
                               QDialog, QHBoxLayout, QHeaderView, QLabel,
                               QMessageBox, QPushButton, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget)

BUS_NAME = "org.ballkey.Daemon"
OBJECT_PATH = "/org/ballkey/Daemon"
INTERFACE = "org.ballkey.Daemon"
REVERT_SECONDS = 15

# Shown for every device that has them, even if not mapped yet.
COMMON_BUTTONS = ["BTN_LEFT", "BTN_RIGHT", "BTN_MIDDLE", "BTN_SIDE",
                  "BTN_EXTRA"]
# Wheel tilt (sideways scrolling). Shown for devices that have it; they
# can't be part of a combination.
TILT_BUTTONS = ["TILT_LEFT", "TILT_RIGHT"]
# Buttons that type keys out of the box on mice we know, by (vendor,
# product). Shown without having to identify them first. Other ones (or
# these, if changed with Piper) are still added with Identify button.
KNOWN_KEY_BUTTONS = {
    # Logitech G502 HERO: the two front buttons below left click.
    ("046d", "c08b"): ["KEY_LEFTCTRL+KEY_C", "KEY_LEFTCTRL+KEY_V"],
}
BUTTON_LABELS = {
    "TILT_LEFT": "Wheel tilt left (scroll left)",
    "TILT_RIGHT": "Wheel tilt right (scroll right)",
    "BTN_LEFT": "Left button",
    "BTN_RIGHT": "Right button",
    "BTN_MIDDLE": "Middle button / wheel click",
    "BTN_SIDE": "Side button (usually Back)",
    "BTN_EXTRA": "Side button (usually Forward)",
    "BTN_FORWARD": "Forward button",
    "BTN_BACK": "Back button",
    "BTN_TASK": "Task button",
}
# Shorter names, for showing combinations like "Left + Right".
BUTTON_SHORT_LABELS = {
    "BTN_LEFT": "Left", "BTN_RIGHT": "Right", "BTN_MIDDLE": "Middle",
    "BTN_SIDE": "Side (Back)", "BTN_EXTRA": "Side (Forward)",
    "BTN_FORWARD": "Forward", "BTN_BACK": "Back", "BTN_TASK": "Task",
}

KEYCOMBO_LABEL = "Keyboard key or combo…"
DRAG_TIP = ("Press once to hold the button down, move, then press again "
            "to let go")
# (action id, label) in dropdown order.
ACTIONS = [
    ("default", "Default (normal behaviour)"),
    ("left", "Left click"),
    ("right", "Right click"),
    ("middle", "Middle click"),
    ("doubleclick", "Double left click"),
    ("doubleright", "Double right click"),
    ("doublemiddle", "Double middle click"),
    ("dragleft", "Left drag"),
    ("dragright", "Right drag"),
    ("dragmiddle", "Middle drag"),
    ("back", "Back"),
    ("forward", "Forward"),
    ("undo", "Undo"),
    ("redo", "Redo"),
    ("cut", "Cut"),
    ("copy", "Copy"),
    ("paste", "Paste"),
    ("selectall", "Select all"),
    ("find", "Find"),
    ("playpause", "Play / pause"),
    ("stop", "Stop"),
    ("nexttrack", "Next track"),
    ("previoustrack", "Previous track"),
    ("volumeup", "Volume up"),
    ("volumedown", "Volume down"),
    ("micmute", "Microphone on/off"),
    ("keycombo", KEYCOMBO_LABEL),
    ("none", "Do nothing"),
]
ACTION_TIPS = {"dragleft": DRAG_TIP, "dragright": DRAG_TIP,
               "dragmiddle": DRAG_TIP}
# A combination always does something, so no "Default" for it.
CHORD_ACTIONS = ACTIONS[1:]

MODIFIER_ORDER = ["KEY_LEFTCTRL", "KEY_RIGHTCTRL", "KEY_LEFTSHIFT",
                  "KEY_RIGHTSHIFT", "KEY_LEFTALT", "KEY_RIGHTALT",
                  "KEY_LEFTMETA", "KEY_RIGHTMETA"]
KEY_LABELS = {
    "KEY_LEFTCTRL": "Ctrl", "KEY_RIGHTCTRL": "Ctrl",
    "KEY_LEFTSHIFT": "Shift", "KEY_RIGHTSHIFT": "Shift",
    "KEY_LEFTALT": "Alt", "KEY_RIGHTALT": "AltGr",
    "KEY_LEFTMETA": "Meta", "KEY_RIGHTMETA": "Meta",
}


def is_key_button(name):
    """A mouse button that types keys (e.g. 'KEY_LEFTCTRL+KEY_C'), as some
    mice like the Logitech G502 have."""
    return name.startswith("KEY_")


def button_label(name):
    if is_key_button(name):
        return f"Button that types {combo_label(name.split('+'))}"
    return BUTTON_LABELS.get(name, f"Extra button ({name})")


def chord_label(buttons):
    return " + ".join(
        combo_label(b.split("+")) if is_key_button(b)
        else BUTTON_SHORT_LABELS.get(b, b.removeprefix("BTN_"))
        for b in buttons)


def key_label(name):
    if name in KEY_LABELS:
        return KEY_LABELS[name]
    short = name.removeprefix("KEY_")
    return short if len(short) <= 3 else short.capitalize()


def combo_label(keys):
    return "+".join(key_label(k) for k in keys)


def evdev_key_name(code):
    """Key name for a kernel key code, or None if BallKey can't send it
    (the daemon's virtual device has the keys from Esc to Mic mute)."""
    if not ecodes.KEY_ESC <= code <= ecodes.KEY_MICMUTE:
        return None
    name = ecodes.KEY.get(code)
    return name[0] if isinstance(name, (list, tuple)) else name


def all_keys():
    """(label, name) of every key BallKey can send, sorted by label."""
    keys = {}
    for code in range(ecodes.KEY_ESC, ecodes.KEY_MICMUTE + 1):
        name = evdev_key_name(code)
        if name:
            keys[name] = name.removeprefix("KEY_").replace("_", " ").title()
    return sorted((label, name) for name, label in keys.items())


def device_key(dev):
    return (dev["vendor"], dev["product"], dev["name"])


# Buttons found with Identify, remembered per device so each one only has
# to be identified once. Kept in the user's own folder: no password needed.
IDENTIFIED_FILE = os.path.join(
    os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"),
    "ballkey", "identified.json")


def identified_key(dev):
    return ":".join(device_key(dev))


def load_identified():
    try:
        with open(IDENTIFIED_FILE) as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def identified_buttons(dev):
    names = load_identified().get(identified_key(dev))
    return {n for n in names if isinstance(n, str)} \
        if isinstance(names, list) else set()


def save_identified(dev, names):
    """Remember these buttons for the device (none: forget them). Not being
    able to save only means identifying them again next time."""
    data = load_identified()
    if names:
        data[identified_key(dev)] = sorted(names)
    else:
        data.pop(identified_key(dev), None)
    try:
        os.makedirs(os.path.dirname(IDENTIFIED_FILE), exist_ok=True)
        with open(IDENTIFIED_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def has_left_click(config):
    """True if some button still does a left click."""
    mappings = config.get("mappings") or {}
    left = mappings.get("BTN_LEFT", {}).get("action", "default")
    if left in ("default", "left"):
        return True
    return any(m.get("action") == "left" for m in mappings.values())


# --- D-Bus -----------------------------------------------------------------

class DaemonClient(QObject):
    """Talks to the BallKey daemon over the system bus."""

    buttonPressed = Signal(str)

    def __init__(self):
        super().__init__()
        # BALLKEY_SESSION_BUS=1 is for development testing only.
        if os.environ.get("BALLKEY_SESSION_BUS"):
            self.bus = QDBusConnection.sessionBus()
        else:
            self.bus = QDBusConnection.systemBus()
        self.iface = QDBusInterface(BUS_NAME, OBJECT_PATH, INTERFACE,
                                    self.bus)
        # Saving may wait for the user to type a password.
        self.iface.setTimeout(300_000)
        self.bus.connect(BUS_NAME, OBJECT_PATH, INTERFACE, "ButtonPressed",
                         self, SLOT("onButtonPressed(QString)"))
        self.watchers = set()

    @Slot(str)
    def onButtonPressed(self, button):
        self.buttonPressed.emit(button)

    def call(self, method, *args):
        """Call and wait for the answer. Raises RuntimeError on failure."""
        msg = self.iface.call(method, *args)
        if msg.type() == QDBusMessage.MessageType.ErrorMessage:
            raise RuntimeError(msg.errorMessage() or msg.errorName())
        values = msg.arguments()
        return values[0] if values else None

    def call_json(self, method, *args):
        return json.loads(self.call(method, *args))

    def set_config(self, config, done):
        """Save in the background (a password prompt may appear).
        done(error_name, error_message) is called when finished;
        both are empty on success."""
        self.call_async("SetConfig", [json.dumps(config)], done)

    def set_boot_enabled(self, enabled, done):
        """Like set_config, for the start-at-boot setting."""
        self.call_async("SetBootEnabled", [enabled], done)

    def call_async(self, method, args, done):
        pending = self.iface.asyncCallWithArgumentList(method, args)
        watcher = QDBusPendingCallWatcher(pending, self)
        self.watchers.add(watcher)

        def finished(w):
            self.watchers.discard(w)
            if w.isError():
                done(w.error().name(), w.error().message())
            else:
                done("", "")
            w.deleteLater()

        watcher.finished.connect(finished)


# --- Dialogs ---------------------------------------------------------------

class KeyComboDialog(QDialog):
    """Records a key combination: hold the keys, then let go."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Record key combo")
        self.keys = []
        self.down = set()
        self.recording = []

        info = QLabel("Press the key or key combination you want, for "
                      "example Ctrl+T, then let go.")
        info.setWordWrap(True)
        self.shown = QLabel("…")
        self.shown.setAlignment(Qt.AlignmentFlag.AlignCenter)
        font = self.shown.font()
        font.setPointSizeF(font.pointSizeF() * 1.6)
        font.setBold(True)
        self.shown.setFont(font)

        self.ok = QPushButton("OK")
        self.ok.setEnabled(False)
        cancel = QPushButton("Cancel")
        # Buttons must not take keyboard focus, or keys like Enter and
        # Space would press them instead of being recorded.
        for b in (self.ok, cancel):
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setAutoDefault(False)
        self.ok.clicked.connect(self.accept)
        cancel.clicked.connect(self.reject)

        # For keys that aren't on this keyboard, or that the desktop
        # catches before the app sees them.
        self.key_list = QComboBox()
        self.key_list.setPlaceholderText("Choose a key to add…")
        for label, name in all_keys():
            self.key_list.addItem(label, name)
        self.key_list.setCurrentIndex(-1)
        self.key_list.activated.connect(self.add_listed_key)
        clear = QPushButton("Clear")
        clear.clicked.connect(self.clear)
        for w in (self.key_list, clear):
            w.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        clear.setAutoDefault(False)
        pick = QHBoxLayout()
        pick.addWidget(QLabel("Or pick from the list:"))
        pick.addWidget(self.key_list, 1)
        pick.addWidget(clear)

        buttons = QHBoxLayout()
        buttons.addStretch()
        buttons.addWidget(cancel)
        buttons.addWidget(self.ok)
        layout = QVBoxLayout(self)
        layout.addWidget(info)
        layout.addWidget(self.shown)
        layout.addLayout(pick)
        layout.addLayout(buttons)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMinimumWidth(360)

    def event(self, e):
        # Catch every key here (including Tab, Enter and Escape) so it is
        # recorded instead of moving focus or closing the dialog.
        if e.type() == e.Type.KeyPress:
            self.key_down(e)
            return True
        if e.type() == e.Type.KeyRelease:
            self.key_up(e)
            return True
        return super().event(e)

    def key_down(self, e):
        if e.isAutoRepeat():
            return
        # On Linux, Qt's native scan code is the kernel key code + 8,
        # whatever the keyboard layout.
        name = evdev_key_name(e.nativeScanCode() - 8)
        if not name:
            self.shown.setText("That key can't be used")
            return
        if not self.down:
            self.recording = []          # a fresh combo starts
        self.down.add(name)
        self.add_key(name)

    def add_listed_key(self, index):
        """A key picked from the list is added to what's shown, so it
        can be combined, e.g. press Ctrl, then pick Print."""
        self.add_key(self.key_list.itemData(index))
        self.key_list.setCurrentIndex(-1)

    def add_key(self, name):
        if name not in self.recording:
            self.recording.append(name)
        # Modifiers first (Ctrl, Shift, Alt, Meta), then the other keys.
        mods = [k for k in MODIFIER_ORDER if k in self.recording]
        rest = [k for k in self.recording if k not in MODIFIER_ORDER]
        self.keys = mods + rest
        self.shown.setText(combo_label(self.keys))
        self.ok.setEnabled(True)

    def clear(self):
        self.recording, self.keys = [], []
        self.shown.setText("…")
        self.ok.setEnabled(False)

    def key_up(self, e):
        if e.isAutoRepeat():
            return
        self.down.discard(evdev_key_name(e.nativeScanCode() - 8))


class ChordDialog(QDialog):
    """Pick the buttons of a new combination."""

    def __init__(self, parent, buttons, taken):
        super().__init__(parent)
        self.setWindowTitle("Add button combination")
        self.taken = taken          # combinations that already exist
        info = QLabel("Tick the buttons to press <b>together</b>, for "
                      "example Left and Right.")
        info.setWordWrap(True)
        layout = QVBoxLayout(self)
        layout.addWidget(info)
        self.boxes = []
        for name in buttons:
            box = QCheckBox(button_label(name))
            box.setProperty("button", name)
            box.toggled.connect(self.update_ok)
            layout.addWidget(box)
            self.boxes.append(box)
        self.problem = QLabel()
        self.problem.setStyleSheet("color: palette(placeholder-text);")
        layout.addWidget(self.problem)
        self.ok = QPushButton("Add")
        cancel = QPushButton("Cancel")
        self.ok.clicked.connect(self.accept)
        cancel.clicked.connect(self.reject)
        row = QHBoxLayout()
        row.addStretch()
        row.addWidget(cancel)
        row.addWidget(self.ok)
        layout.addLayout(row)
        self.setMinimumWidth(360)
        self.update_ok()

    def buttons(self):
        return sorted(b.property("button") for b in self.boxes
                      if b.isChecked())

    def update_ok(self):
        chosen = self.buttons()
        if len(chosen) < 2:
            self.problem.setText("Choose at least two buttons.")
        elif chosen in self.taken:
            self.problem.setText("That combination is already in the list.")
        else:
            self.problem.setText("")
        self.ok.setEnabled(not self.problem.text())


class RevertDialog(QDialog):
    """'Keep these settings?' with an automatic revert countdown."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Keep these settings?")
        self.left = REVERT_SECONDS
        self.text = QLabel()
        self.text.setWordWrap(True)
        keep = QPushButton("Keep changes")
        revert = QPushButton("Revert now")
        # Enter / Escape both revert; keeping needs a deliberate click.
        revert.setDefault(True)
        keep.clicked.connect(self.accept)
        revert.clicked.connect(self.reject)
        buttons = QHBoxLayout()
        buttons.addStretch()
        buttons.addWidget(revert)
        buttons.addWidget(keep)
        layout = QVBoxLayout(self)
        layout.addWidget(self.text)
        layout.addLayout(buttons)
        self.setMinimumWidth(420)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(1000)
        self.update_text()

    def update_text(self):
        self.text.setText(
            "No button is set to <b>Left click</b> any more.<br><br>"
            "If this wasn't on purpose, do nothing: the previous settings "
            f"come back in <b>{self.left}</b> seconds.")

    def tick(self):
        self.left -= 1
        if self.left <= 0:
            self.timer.stop()
            self.reject()
        else:
            self.update_text()


# --- Main window -----------------------------------------------------------

class ActionBox(QComboBox):
    """Action dropdown for one button row."""

    def __init__(self, window, button, actions=ACTIONS):
        super().__init__()
        self.window_ = window
        self.button = button
        self.keys = []
        self.previous = 0
        for action, label in actions:
            self.addItem(label, action)
            if action in ACTION_TIPS:
                self.setItemData(self.count() - 1, ACTION_TIPS[action],
                                 Qt.ItemDataRole.ToolTipRole)
        self.keycombo_index = self.findData("keycombo")
        self.activated.connect(self.on_activated)

    def set_mapping(self, mapping):
        action = (mapping or {}).get("action", self.itemData(0))
        self.keys = list((mapping or {}).get("keys", []))
        index = max(self.findData(action), 0)
        self.setCurrentIndex(index)
        self.previous = index
        self.update_combo_text()

    def mapping(self):
        action = self.currentData()
        if action == "keycombo":
            return {"action": action, "keys": self.keys}
        return {"action": action}

    def update_combo_text(self):
        text = (f"Keys: {combo_label(self.keys)}" if self.keys
                else KEYCOMBO_LABEL)
        self.setItemText(self.keycombo_index, text)

    def on_activated(self, index):
        if index == self.keycombo_index:
            dialog = KeyComboDialog(self.window())
            if dialog.exec() == QDialog.DialogCode.Accepted and dialog.keys:
                self.keys = dialog.keys
                self.update_combo_text()
            elif not self.keys:
                # Cancelled and nothing recorded before: undo the choice.
                self.setCurrentIndex(self.previous)
                return
        self.previous = self.currentIndex()
        self.window_.changed()


class MainWindow(QWidget):
    def __init__(self, client):
        super().__init__()
        self.client = client
        self.saved_config = None       # what the daemon has right now
        self.devices = []              # entries in the device dropdown
        self.extra_rows = set()        # buttons found with Identify
        self.identifying = False
        self.service_ok = False
        self.boot_known = False

        self.setWindowTitle("BallKey – Mouse & Trackball Buttons")
        self.setWindowIcon(QIcon.fromTheme("ballkey",
                                           QIcon.fromTheme("input-mouse")))

        self.device_box = QComboBox()
        self.device_box.setPlaceholderText("No mouse or trackball found")
        self.device_box.currentIndexChanged.connect(self.on_device_chosen)
        self.forget_button = QPushButton("Forget")
        self.forget_button.setToolTip(
            "Remove this device and its button settings from BallKey "
            "(for example a mouse you no longer have)")
        self.forget_button.clicked.connect(self.forget_device)
        top = QHBoxLayout()
        top.addWidget(QLabel("Device:"))
        top.addWidget(self.device_box, 1)
        top.addWidget(self.forget_button)

        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Button", "Action"])
        self.table.verticalHeader().hide()
        self.table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        self.chord_table = QTableWidget(0, 3)
        self.chord_table.setHorizontalHeaderLabels(
            ["Buttons pressed together", "Action", ""])
        self.chord_table.verticalHeader().hide()
        self.chord_table.setSelectionMode(
            QAbstractItemView.SelectionMode.NoSelection)
        self.chord_table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        header = self.chord_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.add_chord_button = QPushButton("Add combination…")
        self.add_chord_button.setToolTip(
            "Make several buttons pressed together do their own action, "
            "e.g. Left + Right together = Middle click")
        self.add_chord_button.clicked.connect(self.add_chord)
        chord_title = QHBoxLayout()
        chord_title.addWidget(QLabel("<b>Button combinations</b>"))
        chord_title.addStretch()
        chord_title.addWidget(self.add_chord_button)

        self.identify_button = QPushButton("Identify button")
        self.identify_button.setToolTip(
            "Press a button on your device to find it in the list")
        self.identify_button.clicked.connect(self.toggle_identify)
        self.defaults_button = QPushButton("Restore defaults")
        self.defaults_button.clicked.connect(self.restore_defaults)
        self.apply_button = QPushButton("Apply")
        self.apply_button.setDefault(True)
        self.apply_button.clicked.connect(self.apply)
        buttons = QHBoxLayout()
        buttons.addWidget(self.identify_button)
        buttons.addStretch()
        buttons.addWidget(self.defaults_button)
        buttons.addWidget(self.apply_button)

        self.boot_box = QCheckBox("Start remapping at boot")
        self.boot_box.setToolTip(
            "When off, buttons behave normally after a restart until you "
            "open BallKey.")
        self.boot_box.clicked.connect(self.toggle_boot)

        self.hint = QLabel()
        self.hint.setWordWrap(True)
        self.status = QLabel()
        self.status.setStyleSheet("color: palette(placeholder-text);")

        layout = QVBoxLayout(self)
        layout.addLayout(top)
        layout.addWidget(self.table, 2)
        layout.addLayout(chord_title)
        layout.addWidget(self.chord_table, 1)
        layout.addWidget(self.hint)
        layout.addLayout(buttons)
        layout.addWidget(self.boot_box)
        layout.addWidget(self.status)
        self.resize(560, 600)

        client.buttonPressed.connect(self.on_button_pressed)
        self.poll = QTimer(self)
        self.poll.timeout.connect(self.refresh_status)
        self.poll.start(2000)
        self.load()

    # -- loading --

    def load(self):
        """(Re)read everything from the daemon."""
        try:
            self.saved_config = self.client.call_json("GetConfig")
            connected = self.client.call_json("ListDevices")
        except RuntimeError:
            self.service_ok = False
            self.refresh_status()
            return
        self.service_ok = True
        self.load_boot_setting()
        self.fill_devices(connected)
        self.update_buttons()
        self.refresh_status()

    def load_boot_setting(self):
        # Optional: if it can't be read (e.g. no systemd), only the
        # checkbox is greyed out; the rest of the app keeps working.
        try:
            self.boot_box.setChecked(bool(self.client.call("GetBootEnabled")))
            self.boot_known = True
        except RuntimeError:
            self.boot_known = False

    def fill_devices(self, connected):
        configured = self.saved_config.get("device")
        current = self.current_device()
        devices = [dict(d, connected=True) for d in connected]
        if configured and device_key(configured) not in map(device_key,
                                                            devices):
            devices.insert(0, dict(configured, connected=False, buttons=[]))
        # The configured device goes first.
        if configured:
            devices.sort(key=lambda d: device_key(d) != device_key(configured))
        if [(device_key(d), d["connected"]) for d in devices] == \
                [(device_key(d), d["connected"]) for d in self.devices]:
            return
        self.devices = devices
        self.device_box.blockSignals(True)
        self.device_box.clear()
        for d in devices:
            text = d["name"] if d["connected"] else \
                f"{d['name']} (not connected)"
            self.device_box.addItem(text)
        keep = current or configured
        index = next((i for i, d in enumerate(devices)
                      if keep and device_key(d) == device_key(keep)), 0)
        self.device_box.setCurrentIndex(index)
        self.device_box.blockSignals(False)
        if current is None or device_key(current) != device_key(
                self.current_device() or current):
            self.on_device_chosen()
        else:
            self.update_buttons()

    def current_device(self):
        i = self.device_box.currentIndex()
        return self.devices[i] if 0 <= i < len(self.devices) else None

    def on_device_chosen(self, *_):
        self.stop_identify()
        dev = self.current_device()
        self.extra_rows = identified_buttons(dev) if dev else set()
        configured = self.saved_config.get("device") if self.saved_config \
            else None
        if dev and configured and device_key(dev) == device_key(configured):
            mappings = self.saved_config.get("mappings") or {}
            chords = self.saved_config.get("chords") or []
        else:
            # another device: starts with normal behaviour
            mappings, chords = {}, []
        self.fill_rows(mappings)
        self.fill_chords(chords)
        if dev and dev.get("keyboard_part"):
            self.hint.setText(
                "Some buttons on this device type keys (like Ctrl+C). If one "
                "isn't in the list, click Identify button and press it.")
        self.update_buttons()

    def fill_rows(self, mappings):
        dev = self.current_device()
        reported = set(dev["buttons"]) if dev else set()
        names = [b for b in COMMON_BUTTONS
                 if b in reported or not dev or not dev["connected"]]
        names += [b for b in TILT_BUTTONS if b in reported]
        if dev and dev.get("keyboard_part"):
            names += KNOWN_KEY_BUTTONS.get(
                (dev["vendor"], dev["product"]), [])
        for b in list(mappings) + sorted(self.extra_rows):
            if b not in names:
                names.append(b)
        self.table.setRowCount(0)
        for name in names:
            self.add_row(name, mappings.get(name))

    def add_row(self, name, mapping=None):
        row = self.table.rowCount()
        self.table.insertRow(row)
        item = QTableWidgetItem(button_label(name))
        item.setToolTip(name)
        item.setData(Qt.ItemDataRole.UserRole, name)
        self.table.setItem(row, 0, item)
        box = ActionBox(self, name)
        box.set_mapping(mapping)
        self.table.setCellWidget(row, 1, box)
        return row

    def fill_chords(self, chords):
        self.chord_table.setRowCount(0)
        for chord in chords:
            self.add_chord_row(chord["buttons"], chord)

    def add_chord_row(self, buttons, mapping=None):
        buttons = sorted(buttons)
        row = self.chord_table.rowCount()
        self.chord_table.insertRow(row)
        item = QTableWidgetItem(chord_label(buttons))
        item.setToolTip(" + ".join(buttons))
        self.chord_table.setItem(row, 0, item)
        box = ActionBox(self, buttons, CHORD_ACTIONS)
        box.set_mapping(mapping)
        self.chord_table.setCellWidget(row, 1, box)
        remove = QPushButton("Remove")
        remove.clicked.connect(lambda: self.remove_chord(box))
        self.chord_table.setCellWidget(row, 2, remove)

    def chord_boxes(self):
        return [self.chord_table.cellWidget(row, 1)
                for row in range(self.chord_table.rowCount())]

    def add_chord(self):
        buttons = [self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)
                   for row in range(self.table.rowCount())]
        buttons = [b for b in buttons if b not in TILT_BUTTONS]
        taken =[box.button for box in self.chord_boxes()]
        dialog = ChordDialog(self, buttons, taken)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        # Middle click is the usual reason for a combination.
        self.add_chord_row(dialog.buttons(), {"action": "middle"})
        self.hint.setText("Combination added. Buttons in a combination "
                          "react a tiny bit later. Click Apply to save.")
        self.update_buttons()

    def remove_chord(self, box):
        for row, b in enumerate(self.chord_boxes()):
            if b is box:
                self.chord_table.removeRow(row)
                break
        self.update_buttons()

    def row_of(self, name):
        for row in range(self.table.rowCount()):
            if self.table.item(row, 0).data(Qt.ItemDataRole.UserRole) == name:
                return row
        return None

    # -- editing --

    def build_config(self):
        dev = self.current_device()
        mappings = {}
        for row in range(self.table.rowCount()):
            box = self.table.cellWidget(row, 1)
            m = box.mapping()
            if m["action"] != "default":
                mappings[box.button] = m
        chords = [dict(box.mapping(), buttons=box.button)
                  for box in self.chord_boxes()]
        return {"version": 1,
                "device": {k: dev[k] for k in ("vendor", "product", "name")}
                if dev else None,
                "mappings": mappings,
                "chords": chords}

    def has_changes(self):
        if not self.saved_config or not self.current_device():
            return False
        new = self.build_config()
        return (new["device"] != self.saved_config.get("device")
                or new["mappings"] != (self.saved_config.get("mappings")
                                       or {})
                or new["chords"] != (self.saved_config.get("chords") or []))

    def changed(self):
        self.update_buttons()

    def update_buttons(self):
        dev = self.current_device()
        ok = self.service_ok and dev is not None
        self.device_box.setEnabled(self.service_ok)
        self.boot_box.setEnabled(self.service_ok and self.boot_known)
        self.table.setEnabled(ok)
        self.chord_table.setEnabled(ok)
        self.add_chord_button.setEnabled(ok)
        self.defaults_button.setEnabled(ok)
        self.identify_button.setEnabled(ok and dev["connected"])
        self.apply_button.setEnabled(ok and self.has_changes())
        self.forget_button.setEnabled(ok and self.is_saved_device(dev))

    def is_saved_device(self, dev):
        saved = (self.saved_config or {}).get("device")
        return bool(dev and saved and device_key(dev) == device_key(saved))

    def restore_defaults(self):
        for row in range(self.table.rowCount()):
            self.table.cellWidget(row, 1).set_mapping(None)
        self.chord_table.setRowCount(0)
        self.hint.setText("All buttons set to Default and combinations "
                          "removed. Click Apply to save.")
        self.update_buttons()

    # -- identify --

    def toggle_identify(self):
        if self.identifying:
            self.stop_identify()
            return
        dev = self.current_device()
        try:
            self.client.call("StartIdentify", dev["vendor"], dev["product"],
                             dev["name"])
        except RuntimeError as e:
            self.hint.setText(f"Can't identify buttons: {e}")
            return
        self.identifying = True
        self.identify_button.setText("Stop")
        self.hint.setText("Press a button on your device…")

    def stop_identify(self):
        if not self.identifying:
            return
        self.identifying = False
        self.identify_button.setText("Identify button")
        try:
            self.client.call("StopIdentify")
        except RuntimeError:
            pass

    def on_button_pressed(self, name):
        if not self.identifying:
            return
        self.stop_identify()
        row = self.row_of(name)
        if row is None:
            self.extra_rows.add(name)
            save_identified(self.current_device(), self.extra_rows)
            row = self.add_row(name)
        self.table.selectRow(row)
        self.table.scrollToItem(self.table.item(row, 0))
        self.hint.setText(f"You pressed: {button_label(name)}")

    # -- saving --

    def apply(self):
        new = self.build_config()
        old = self.saved_config
        self.set_busy(True, "Saving… (a password prompt may appear)")

        def done(error_name, error_message):
            self.set_busy(False)
            if error_name:
                self.show_save_error(error_name, error_message)
                return
            self.saved_config = new
            self.hint.setText("Settings saved.")
            self.update_buttons()
            if not has_left_click(new):
                self.confirm_or_revert(old)

        self.client.set_config(new, done)

    def confirm_or_revert(self, old):
        if RevertDialog(self).exec() == QDialog.DialogCode.Accepted:
            return
        self.set_busy(True, "Reverting to the previous settings…")

        def done(error_name, error_message):
            self.set_busy(False)
            if error_name:
                self.show_save_error(error_name, error_message)
                return
            self.saved_config = old
            self.on_device_chosen()
            self.hint.setText("Previous settings restored.")

        self.client.set_config(old, done)

    def forget_device(self):
        dev = self.current_device()
        answer = QMessageBox.question(
            self, "Forget device?",
            f"Forget <b>{dev['name']}</b>?<br><br>Its button settings and "
            "identified buttons will be removed and it will behave "
            "normally. You can set it up again any time while it's "
            "connected.")
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.stop_identify()
        new = {"version": 1, "device": None, "mappings": {}, "chords": []}
        self.set_busy(True, "Saving… (a password prompt may appear)")

        def done(error_name, error_message):
            self.set_busy(False)
            if error_name:
                self.show_save_error(error_name, error_message)
                return
            self.saved_config = new
            save_identified(dev, set())
            self.load()
            self.on_device_chosen()   # show the rows without its settings
            self.hint.setText(f"Forgot {dev['name']}.")

        self.client.set_config(new, done)

    def toggle_boot(self, enabled):
        self.set_busy(True, "Saving… (a password prompt may appear)")

        def done(error_name, error_message):
            self.set_busy(False)
            if error_name:
                self.boot_box.setChecked(not enabled)   # undo the click
                self.show_save_error(error_name, error_message)
            elif enabled:
                self.hint.setText("Remapping will start at boot.")
            else:
                self.hint.setText("Remapping won't start at boot. After a "
                                  "restart, open BallKey to turn it on.")

        self.client.set_boot_enabled(enabled, done)

    def show_save_error(self, name, message):
        if name.endswith("NotAuthorized"):
            self.hint.setText("Not saved: the password was not given.")
        else:
            self.hint.setText("Not saved.")
            QMessageBox.warning(self, "Couldn't save settings",
                                message or name)

    def set_busy(self, busy, text=""):
        for w in (self.device_box, self.table, self.identify_button,
                  self.defaults_button, self.apply_button, self.boot_box,
                  self.forget_button, self.chord_table,
                  self.add_chord_button):
            w.setEnabled(not busy)
        if busy:
            self.hint.setText(text)
        else:
            self.update_buttons()

    # -- status --

    def refresh_status(self):
        try:
            status = self.client.call_json("Status")
        except RuntimeError:
            if self.service_ok:
                self.service_ok = False
                self.stop_identify()
                self.update_buttons()
            self.status.setText("● Service not running")
            return
        if not self.service_ok:
            self.load()   # the service just came back
            return
        try:
            self.fill_devices(self.client.call_json("ListDevices"))
        except RuntimeError:
            pass
        parts = ["Service running"]
        if not status["configured"]:
            parts.append("No device set up yet")
        elif status["device_connected"]:
            parts.append("Device connected")
        else:
            parts.append("Device not connected")
        if status.get("last_error"):
            parts.append(status["last_error"])
        self.status.setText(" · ".join(parts))

    def closeEvent(self, event):
        self.stop_identify()
        super().closeEvent(event)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("BallKey")
    app.setDesktopFileName("ballkey-settings")
    window = MainWindow(DaemonClient())
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
